# TRABALHO_POO_31553

Licenciatura em Engenharia de Sistemas Informáticos 2025-26 (**laboral**)

Programação Orientada a Objetos 

| Número | Nome |
| -----   | ---- |
|  31553     |  Vitor Moreira  |

## Organização

Código da solução desenvolvida:

[GestaoAlojamentos.DA/](./GestaoAlojamentos.DA/) 

[GestaoAlojamentos.BO/](./GestaoAlojamentos.BO/)

[GestaoAlojamentos.Controller/](./GestaoAlojamentos.Controller/)

[teste/](./teste/) 

Acesso ao Relatório:

[doc/](.doc/) 

## Download do Projeto

Para aceder ao downlaod da fase final, a partir do repositório GITHUB realizar o download do ficheiro "TrabalhoPOO_31553_fase2.zip"

## Compilação do Programa

Através do Visual Studio em primeira instância compilar o programa

