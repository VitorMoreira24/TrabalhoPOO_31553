﻿namespace GestaoAlojamentos.UnitaryTests
{
    public class Class1
    {

    }
}
